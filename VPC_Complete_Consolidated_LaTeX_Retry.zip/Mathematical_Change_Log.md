# Sections 1–3 (and abstract): mathematical and editorial change log

## Provenance
Baseline: `VPC_Appendices_Consolidated_Theory_Manuscript.zip`, *not* a reconstructed earlier manuscript. The revised Sections 4–8, Appendices A–L, and the companion `Completed_Proofs.tex` are retained exactly in this edition. All original Section 1–3 source files are also archived unchanged.

## Abstract
- Corrected the description of the contributions to include pointwise endpoint calibration, equality/directional tests, nuisance-dependent PSD chart, rank-free confidence regions, and restricted compact-uniform results.
- Avoided implying that simulation or implementation claims have been established.

## Section 1 (Introduction)
- Extended the hypothesis overview from global/pointwise zero to equality and directional VPC contrasts.
- Replaced the outdated statement that uniform covariance-rank-transition inference is left for future research, because the completed proof supplement provides restricted compact-uniform results.
- Updated the contribution paragraph to accurately describe the Gaussian envelope, exact PSD-preserving chart, and rank-free CI methods; retained the four-family scope with both CPG dispersion and power unknown.
- Qualified the theoretical claims by informative finite-type designs, compact fitted domain, nonsingular information, and exact likelihood; left the four-endpoint *sharpness* conjecture open.
- Made the paper organization prospective regarding the still-unfinished simulation, real-data, and discussion sections.

## Section 2 (GLMM and VPC)
- Preserved every original equation, proposition, and label, including the response-scale VPC and NB2/CPG expressions.
- Clarified that finite informative-design assumptions for uniform inference strengthen the general bounded-cluster setup.
- Added variance-link notation R_x(v,lambda) and its strict monotonicity, proved in the completed supplement's Lemma 9.1.
- Introduced the directional null H0,+: Delta_rho<=0, matching the established sign convention in Section 7.
- Qualified the simulation-calibration language: parameter calibration does not imply likelihood numerical accuracy.

## Section 3 (Fisher information)
- Preserved all existing information definitions, propositions, displayed equations and labels.
- Clarified deterministic *identities* vs numerical evaluation of family-specific expectations.
- Linked completed boundary/interchange arguments to the verified compact-class theorem, without claiming generic unrestricted GLMM regularity.
- Clarified that the full information transforms before nuisance profiling for a nuisance-dependent covariance chart at nonzero Gamma.
- Distinguished model-expected vertex information from inconsistent observed-Hessian-at-false-vertex estimators.
- Added exact-likelihood vs numerical-accuracy qualification and fixed a missing terminal period.

## Scope decision
No new LRT, VPC formula, or asymptotic claim was introduced independently. The updates align the front matter with the already completed and separately audited proofs. The four-endpoint equality conjecture is **not** claimed proved. Current R software accuracy is **not** claimed certified.
