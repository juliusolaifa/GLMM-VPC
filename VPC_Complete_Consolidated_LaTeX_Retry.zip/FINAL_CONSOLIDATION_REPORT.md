# VPC manuscript — integrated theory consolidation

## Delivery and scope

This is the complete, separately compiled **theory-only** Biometrics-format draft: revised abstract and Sections 1–8, original and reconciled supporting proofs in Appendices A–L, and a **separate** 49-page companion `Completed_Proofs.tex`/PDF. The existing unfinished Sections 9–11 are retained as source files but intentionally excluded from `main_.tex` and replaced by explicitly labelled placeholders. Appendix J is reserved for simulation algorithms. `main_full_future.tex` is a separate future assembly file and must not be treated as validated until the empirical sections are updated.

The original ZIP, original Appendices K and L, original competing H and I, and the original manuscript master are retained under `original_sources`. No original source was overwritten in the source archive.

## Theorem and appendix reconciliation

- Sections 1–3: full revisions to abstract, motivation, model definition and Fisher-information context; original labels from Sections 1–8 are retained.
- Sections 4–6: the compact informative-design/compact-fitting scope is explicit. Gaussian global and pointwise cone limits are separated from their four-family compact-uniform transfer.
- Section 7: equality/directional tests use the exact nuisance-dependent PSD chart. Their information-dependent calibration transforms the **full** information before profiling. The conservative information-free mixture is valid for arbitrary positive-definite efficient information coupling on the verified classes. The sharper four-endpoint conjecture remains open.
- Section 8: preserves the original rank-adaptive fixed-parameter analysis and adds rank-free score/ellipsoid, CPG moment, and conservative all-level LR confidence-region results under stated assumptions.
- Appendix H: canonical equality/directional geometrical proofs, using the fuller original Appendix I rather than duplicating H and I.
- Appendix I: a proof location map that points to the 49-page **separate** companion. The map is not itself a substitute for that proof document.
- Appendices K/L: complete original analytic and moment sources included in the paper; the companion supplies the additional completed proofs. Removed two author-facing placement/polish instructions in the final editorial pass, leaving substantive mathematics unchanged.
- Appendix J: explicit placeholder for simulation algorithms; intentionally incomplete.

## Exact checks performed

- LaTeX compilation: `pdflatex` completed successfully twice after the last editorial pass, using the bundled generated `.bbl`. The full companion `Completed_Proofs.tex` also compiled twice successfully.
- Main theory draft: **57 pages**. Companion completed proofs: **49 pages**.
- Missing original labels in revised Sections 1–8: **0**.
- Duplicate active LaTeX labels: **0** (626 unique labels in active section and appendix sources).
- Undefined references reported by LaTeX: **0**.
- Undefined citations reported by LaTeX: **0**.
- Duplicate bibliography entry keys: **0** (25 keys).
- Literal `??` strings in active sources: **0**.
- Nonfatal TeX layout diagnostics: 56 overfull horizontal boxes (all generated while the journal class's page header is active), 1 small overfull vertical box, and the class-level preexisting `thetheorem` warning. Visual checks show the rendered pages remain readable. These class-specific warnings can be cleaned at journal typesetting without changing the science.
- BibTeX executable was not available in this current runtime; the already generated `.bbl`, original `.bib`, and bibliography style are included, and no citations are unresolved after recompilation. A full BibTeX regeneration may be run on a local complete TeX installation.

## Intentionally unfinished

1. Section 9: final simulation designs, numerical tables, figures and interpretation; Appendix J's full algorithm statements.
2. Section 10: final real-data application.
3. Section 11: final discussion, limitations and implications.

Theoretical conditions requiring certified numerical optimization and integration accuracy remain **outside this manuscript's current implementation verification**. The mathematical results are stated for exact global likelihood suprema and restricted informative compact model classes; they do not constitute a claim of unrestricted-design or unbounded-fitting uniform validity.

## Author-facing publication tasks

- Replace the journal template's placeholder volume, DOI and publication-date metadata when appropriate (these are class-generated placeholders, not study results).
- Decide journal length limits and whether the companion proof document should be a supplementary PDF.
- Compile `main_.tex` with a full TeX installation (BibTeX enabled) after adding Sections 9–11.
