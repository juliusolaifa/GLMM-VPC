# Proof dependency map for revised Sections 1–3

| Statement | Authoritative support | Boundaries / status |
|---|---|---|
| Response-scale VPC and conditional law of total variance | Original Appendix A; original Section 2 definitions | Original results preserved |
| Zero-VPC iff Gamma z=0 and gradient | Appendix A, zero-VPC propositions | Requires positive observation variance |
| Variance-link strict monotonicity | Completed_Proofs.tex, Lemma 9.1 | Gaussian identity, Poisson/NB2/CPG log links, compact admissible sets |
| Equality/directional PSD chart | Completed_Proofs.tex, Theorem 9.2 and Section 7 revised | Distinct xa,xb; transform full information before profiling |
| Compact-uniform four-family GLMM likelihood | Completed_Proofs.tex, Sections 1–6; Appendix K; Appendix G | Independent bounded clusters, informative designs, fixed nuisance dimension, compact fit, SPD aggregate I |
| Gaussian global chi-bar law | Original Sections 4–5; Appendix E | Correct I_eff cone metric; exact fitting and calibration |
| Pointwise endpoint envelope | Original Section 6; Appendix F4; Completed_Proofs.tex, Sections 5–6 | Nonzero vertex-local and remote null regimes, verified uniformity restricted to compact classes |
| Conservative equality/directional calibration | Revised Section 7; Completed_Proofs.tex, Theorem 9.4/Cor. 9.5 | Arbitrary SPD coupling allowed, no four-endpoint identity required |
| Rank-free coverage and CPG moments | Revised Section 8; Appendix L; Completed_Proofs.tex, Sections 7–8 | Compact informative classes; full-dimensional conservative cutoffs |
| Information moments (6 blocks) at Gamma=0 | Original Appendix B, Proposition B.1 | Not a generic nonzero-covariance FIM identity |
| Numeric likelihood accuracy | Completed_Proofs.tex, Section 13 | Existing implementation unverified |
