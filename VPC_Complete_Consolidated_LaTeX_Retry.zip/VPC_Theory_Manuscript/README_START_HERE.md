# VPC theory manuscript — appendix-consolidation working edition

Open `paper/main_.pdf` to read the integrated theory-only preview. The editable master is `paper/main_.tex`; all `section*.tex` inputs and the `.bib`, `.bbl`, class and style are included.

**Proposed revised sections:** 4–8 are the most recent complete-section proposals supplied in this conversation. Sections 1–3 and Appendices A–G are unedited from the source project. Appendix H is the de-duplicated equality/directional source (selected from original Appendix I). New Appendix I is a map to the substantive companion proof supplement. K and L come from the user's newly uploaded sources with documented minimal corrections. Original full project and sources are archived under `original_sources/`.

`Supplementary_Completed_Proofs/Completed_Proofs.tex` and `Completed_Proofs_original.pdf` are the authoritative detailed proof supplement. `Manuscript_Patches.tex` is a historical edit reference, not a second main input.

The theory-only PDF intentionally excludes Sections 9–11 (simulations, real data, discussion). Their original source files remain in `paper/` and can be enabled by uncommenting the three `\input` lines in `paper/main_.tex`. Missing cross-references to those sections are therefore expected in this preview; no statistical result is being asserted for unperformed simulations.

The master was compiled with `pdflatex` + `bibtex8` + `pdflatex` twice in a scratch working environment. Final journal style and supplementary partition have not been settled.
