# VPC theory manuscript -- appendices consolidated

Start with `paper/main_.tex`. It compiles the integrated **theory-only** draft and deliberately labeled placeholders for Sections 9--11.

`paper/main_full_future.tex` is a master variant that includes the author's original simulation, real-data and discussion drafts. Those are **not finalized**. It may require unavailable figure files.

`paper/section19:appendixH.tex` is the canonical merged equality appendix (originals are archived).
`paper/section20:appendixI.tex` is the supporting proof index.
`paper/section22:appendixK.tex` and `paper/section23:appendixL.tex` contain the user-supplied standalone sources adapted for the master bibliography.

`Supplementary_Completed_Proofs/Completed_Proofs.tex` is the authoritative long-form mathematical supplement, and the companion PDF is included. This file is NOT included again inside the paper master, avoiding substantial duplicate content.

To compile: cd paper; pdflatex main_.tex; bibtex8 main_; pdflatex main_.tex; pdflatex main_.tex.

The original sources and the user's ZIP are archived. This is an editorial proposal and should be reviewed before being treated as the final manuscript.
